# Install and load the nflfastR package
if (!requireNamespace("nflfastR", quietly = TRUE)) {
  install.packages("nflfastR")
}
library(nflfastR)

# Loop through the last 15 years to fetch play-by-play data
for(year in 1999:2023) {
  pbp_data <- load_pbp(year)
  
  # Save the raw data to a CSV file
  write.csv(pbp_data, paste0('./data-raw-git-2/play_by_play_', year, '.csv'))
}
