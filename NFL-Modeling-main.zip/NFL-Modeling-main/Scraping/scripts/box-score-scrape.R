# Specify a CRAN mirror and install the nflfastR package if not already installed
if (!requireNamespace("nflfastR", quietly = TRUE)) {
  install.packages("nflfastR", repos = "https://cloud.r-project.org/")
}

# Load the nflfastR library
library(nflfastR)

# Loop through the last 15 years to fetch box scores
for(year in 1999:2023) {
  # Fetch box scores
  box_scores <- load_scores(year)
  
  # Save the box scores to a CSV file
  write.csv(box_scores, paste0('./data-raw-git-2/box_scores_', year, '.csv'))
}

